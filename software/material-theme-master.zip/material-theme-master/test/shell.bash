#!/bin/bash
echo "$RANDOM"  # Supported in bash. No warnings.
