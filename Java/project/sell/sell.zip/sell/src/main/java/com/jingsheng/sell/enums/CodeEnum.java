package com.jingsheng.sell.enums;

/**
 *
 */
public interface CodeEnum<T> {

    T getCode();
}
