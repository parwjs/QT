package com.jingsheng.sell.exception;

/**
 *
 */
public class SellerAuthorizeException extends RuntimeException {
}
