package com.jingsheng.sell.service.impl;

import com.jingsheng.sell.dataobject.SellerInfo;
import com.jingsheng.sell.repository.SellerInfoRepository;
import com.jingsheng.sell.service.SellerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 */
@Service
public class SellerServiceImpl implements SellerService {

    @Autowired
    private SellerInfoRepository repository;

    @Override
    public SellerInfo findSerllerInfoByOpenid(String openid) {
        return repository.findByOpenid(openid);
    }
}
