package com.jingsheng.sell.service;

import com.jingsheng.sell.dto.OrderDTO;
import com.lly835.bestpay.model.PayResponse;
import com.lly835.bestpay.model.RefundResponse;

/**
 *
 */
public interface PayService {

    /**
     * 创建支付
     * @param orderDTO
     * @return
     */
    PayResponse create(OrderDTO orderDTO);

    /***
     * 微信通知
     * @param notifyData
     * @return
     */
    PayResponse notify(String notifyData);

    /***
     * 退款
     * @param orderDTO
     */
    RefundResponse refund(OrderDTO orderDTO);
}
