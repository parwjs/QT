package com.jingsheng.sell.exception;

/**
 *
 */
public class ResponseBankException extends RuntimeException{
}
