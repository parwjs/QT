package com.jingsheng.sell;

/**
 *
 */
public class LoggerTest2 {
}
