package com.jingsheng.sell.service.impl;

import com.jingsheng.sell.dataobject.SellerInfo;
import com.jingsheng.sell.repository.SellerInfoRepository;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

/**
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class SellerServiceImplTest {

    @Autowired
    private SellerInfoRepository repository;

    private static final String OPENID = "abc";

    @Test
    public void findSerllerInfoByOpenid() {

        SellerInfo result = repository.findByOpenid(OPENID);
        Assert.assertEquals(OPENID,result.getOpenid());


    }
}